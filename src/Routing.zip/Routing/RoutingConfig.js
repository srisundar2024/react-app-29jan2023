import { Routes, Route } from "react-router";

import Home from "./Home";
import About from "./About";
import Contact from "./Contact";
import Unauthorized from "./Unauthorized";

function RoutingConfig()
{
    return <>
            <Routes>
                <Route path="/" element={<Home></Home>} />
                <Route path="about" element={<About></About>} />
                <Route path="contact1" element={<Contact></Contact>} />
                <Route path="*" element={<Unauthorized></Unauthorized>} />
            </Routes>
        </>
}

export default RoutingConfig;