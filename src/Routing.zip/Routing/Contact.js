function Contact()
{
    return <h1>This is my Contact Page</h1>
}

export default Contact;