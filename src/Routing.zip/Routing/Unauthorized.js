function Unauthorized()
{
    return <h1>You are not authorized for this page</h1>
}

export default Unauthorized;