function Home()
{
    return <h1>This is my Home Page</h1>
}

export default Home;